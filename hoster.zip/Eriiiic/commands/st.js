// Require necessary files and modules
const strings = require("../strings.json");
const allowedUsers = require("../allowed.json").allowed;

module.exports = {
    names: {
        list: ["stu"]  // List of command aliases
    },
    execute: async (client, message, args) => {
        // Check if the message is sent in a guild
        if (!message.guild) {
            return message.channel.send(strings.notInGuild);
        }

        // Check if the message author is allowed to change the status
        if (!allowedUsers.includes(message.author.id)) {
            return message.channel.send(strings.noPermission);
        }

        // Check if the command has the correct number of arguments
        if (args.length !== 1) {
            return message.channel.send(strings.invalidArgs11); // Update this in your strings.json
        }

        const status = args[0].toLowerCase();  // Get the status argument (e.g., "online", "idle", "dnd")

        // Validate the status argument
        if (!["online", "idle", "dnd"].includes(status)) {
            return message.channel.send(strings.invalidStatus); // Update this in your strings.json
        }

        try {
            // Set the bot's status based on the argument provided
            await client.user.setStatus(status);

            // Send a confirmation message
            message.channel.send(strings.statusChanged.replace("{status}", status));
        } catch (error) {
            // Log the error
            console.error("Error occurred while changing status:", error);

            // Send the error to the specified text channel
            const errorChannelId = '1221249421581226014'; // Replace with your error channel ID
            const errorChannel = client.channels.cache.get(errorChannelId);
            if (errorChannel && errorChannel.isText()) {
                errorChannel.send(`Error occurred while changing status: \`\`\`${error}\`\`\``);
            } else {
                console.error("Error channel not found or not a text channel.");
            }

            message.channel.send(strings.errorChangingStatus);
        }
    }
};
