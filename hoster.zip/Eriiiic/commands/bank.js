const { Client, Intents } = require('discord.js-selfbot-v13');
const allowedUsers = require("../allowed.json").allowed;
const messages = require("../bank.json").messages; // Assuming your JSON file is named bank.json

let interval;

module.exports = {
    names: {
        list: ["bank"]
    },
    execute: async (client, message, args) => {
        try {
            if (!allowedUsers.includes(message.author.id)) {
                message.channel.send("You don't have permission to use this command.");
                return;
            }

            if (args.length < 1) {
                message.channel.send("Please provide a text channel.");
                return;
            }

            let channel = message.mentions.channels.first() || client.channels.cache.get(args[0]);
            if (!channel) {
                message.channel.send("Please provide a valid text channel.");
                return;
            }

            if (interval) {
                clearInterval(interval);
                interval = null;
                message.channel.send(`Stopped playing bank in ${channel.toString()}`);
                return;
            }

            // Function to send a random message
            const sendRandomMessage = async () => {
                const randomMessage = messages[Math.floor(Math.random() * messages.length)];
                await channel.send(randomMessage);
            };

            // Send a random message every 5 minutes (300000 milliseconds)
            interval = setInterval(sendRandomMessage, 300000);
            await sendRandomMessage(); // Send the first message immediately

            message.channel.send(`**Started playing bank in ${channel.toString()}.**`);
        } catch (error) {
            console.error("Error occurred while sending the message:", error);
            message.channel.send("An error occurred while trying to send the message.");
        }
    }
};
