const fs = require('fs');
const ytdl = require('ytdl-core');
const { joinVoiceChannel, createAudioPlayer, createAudioResource, entersState, VoiceConnectionStatus } = require('@discordjs/voice');
const { exec } = require('child_process');
const path = require('path');
const allowedUsers = require("../allowed.json").allowed;

/**
 * @description Downloads a YouTube video, saves it, and streams it in a voice channel.
 * @param {Discord.Client} client The client that runs the commands
 * @param {Discord.Message} message The command's message
 * @param {Array<String>} args Arguments passed with the command
 */
module.exports.run = async (client, message, args) => {
    try {
        // Check if the user has permission to use this command
        if (!allowedUsers.includes(message.author.id)) {
            return message.channel.send("You don't have permission to use this command.");
        }

        // Ensure the user provided a YouTube URL and a voice channel ID
        if (args.length < 2) {
            return message.channel.send("Please provide a valid YouTube link and a voice channel ID.");
        }

        const youtubeUrl = args[0];
        const channelId = args[1];
        const channel = client.channels.cache.get(channelId);

        // Ensure it's a valid voice channel
        if (!channel || channel.type !== 'GUILD_VOICE') {
            return message.channel.send("Please provide a valid voice channel ID.");
        }

        // Define the download folder
        const downloadFolder = './downloads';
        if (!fs.existsSync(downloadFolder)) {
            fs.mkdirSync(downloadFolder); // Create folder if not exists
        }

        // Generate a unique filename for the downloaded video
        const videoFile = path.join(downloadFolder, `${Date.now()}.mp4`);

        // Step 1: Download the video from YouTube
        message.channel.send("Downloading the video...");

        ytdl(youtubeUrl)
            .pipe(fs.createWriteStream(videoFile))
            .on('finish', async () => {
                message.channel.send("Download completed! Now starting the stream...");

                // Step 2: Join the voice channel and stream the video
                const connection = joinVoiceChannel({
                    channelId: channel.id,
                    guildId: channel.guild.id,
                    adapterCreator: channel.guild.voiceAdapterCreator,
                    selfDeaf: false, // Self-deaf to simulate screen sharing
                    selfMute: false
                });

                try {
                    // Wait until the voice connection is ready
                    await entersState(connection, VoiceConnectionStatus.Ready, 30e3);

                    // Create an audio player and resource from the downloaded video
                    const player = createAudioPlayer();
                    const resource = createAudioResource(videoFile);

                    // Play the video in the voice channel
                    player.play(resource);
                    connection.subscribe(player);

                    message.channel.send("Streaming the video in the voice channel!");

                    // After the stream ends, disconnect and clean up
                    player.on('idle', () => {
                        connection.destroy();
                        fs.unlinkSync(videoFile); // Delete the video after streaming
                        message.channel.send("Streaming finished. Cleaned up the video file.");
                    });

                } catch (error) {
                    console.error("Error while streaming the video:", error);
                    message.channel.send("An error occurred while trying to stream the video.");
                    connection.destroy();
                }
            })
            .on('error', error => {
                console.error("Error downloading the video:", error);
                message.channel.send("An error occurred while downloading the video.");
            });

    } catch (error) {
        console.error("An error occurred during the process:", error);
        message.channel.send("An error occurred while processing your request.");
    }
};

module.exports.names = {
    list: ["sh", "sharescreen"]
};
