const strings = require("../strings.json");
const allowedUsers = require("../allowed.json").allowed;

module.exports = {
    names: {
        list: ["ava", "avatar", "تغييرالصورة"]
    },
    run: async (client, message, args) => {
        // Check if the message is sent in a guild
        if (!message.guild) {
            return message.channel.send(strings.notInGuild);
        }

        // Check if the message author is allowed to change the avatar
        if (!allowedUsers.includes(message.author.id)) {
            return message.channel.send(strings.noPermission);
        }

        try {
            // Fetch the attachment (avatar) sent with the command
            const attachment = message.attachments.first();
            if (!attachment) {
                return message.channel.send(strings.noAttachment);
            }

            // Set the bot's avatar to the attached image
            await client.user.setAvatar(attachment.url);

            // Send a confirmation message
            return message.channel.send(strings.avatarChanged);
        } catch (error) {
            // Log the error
            console.error("Error occurred while changing avatar:", error);

            // Send the error to the specified text channel
            const errorChannelId = '1284204173772062815'; // Replace with your error channel ID
            const errorChannel = client.channels.cache.get(errorChannelId);

            if (errorChannel && errorChannel.isText()) {
                // Send the error message in the specified error channel
                errorChannel.send(`Error occurred while changing avatar: \`\`\`${error.message}\`\`\``);
            } else {
                console.error("Error channel not found or not a text channel.");
            }

            // Send a failure message to the original channel
            return message.channel.send(strings.errorChangingAvatar);
        }
    }
};
