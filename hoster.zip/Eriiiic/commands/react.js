const allowedUsers = require("../allowed.json").allowed;
let activeReactListeners = new Map(); // To keep track of active listeners

module.exports = {
    names: {
        list: ["react", "stopreact"]
    },
    run: async (client, message, args) => {
        try {
            const targetChannelId = '1284204173772062815'; // Channel for bot messages
            const targetChannel = client.channels.cache.get(targetChannelId);

            // Permission check
            if (!allowedUsers.includes(message.author.id)) {
                targetChannel.send("You don't have permission to use this command.");
                return;
            }

            const command = message.content.split(" ")[0].slice(1); // Get the command name ('react' or 'stopreact')

            if (command === 'react') {
                // Ensure both a channel ID and emoji are provided
                if (args.length < 2) {
                    targetChannel.send("Please provide both a channel ID and an emoji.");
                    return;
                }

                const textChannelId = args[0];  // The channel to watch
                const emoji = args[1];          // The emoji to react with
                const textChannel = client.channels.cache.get(textChannelId);

                if (!textChannel || textChannel.type !== 'GUILD_TEXT') {
                    targetChannel.send("Please provide a valid text channel ID.");
                    return;
                }

                // Check if a listener is already active for this channel
                if (activeReactListeners.has(textChannelId)) {
                    targetChannel.send(`Bot is already reacting to messages in <#${textChannelId}>.`);
                    return;
                }

                // Create and store a listener for the specified text channel
                const reactListener = async (msg) => {
                    // Ignore bot messages and messages outside the target channel
                    if (msg.author.bot || msg.channel.id !== textChannelId) return;

                    try {
                        // React to the message with the specified emoji
                        await msg.react(emoji);
                    } catch (error) {
                        console.error("Failed to react to the message:", error);
                        targetChannel.send("An error occurred while reacting to a message.");
                    }
                };

                // Add the listener to the client and the active listeners map
                client.on('messageCreate', reactListener);
                activeReactListeners.set(textChannelId, reactListener);

                targetChannel.send(`Bot will now react to every message in <#${textChannelId}> with ${emoji}.`);

            } else if (command === 'stopreact') {
                // Stop reacting to messages
                if (args.length < 1) {
                    targetChannel.send("Please provide the channel ID to stop reacting to.");
                    return;
                }

                const textChannelId = args[0];

                if (!activeReactListeners.has(textChannelId)) {
                    targetChannel.send(`No active reaction listener found for <#${textChannelId}>.`);
                    return;
                }

                // Remove the listener for the specified channel
                const reactListener = activeReactListeners.get(textChannelId);
                client.off('messageCreate', reactListener);
                activeReactListeners.delete(textChannelId);

                targetChannel.send(`Bot has stopped reacting to messages in <#${textChannelId}>.`);
            }

        } catch (error) {
            console.error("Error occurred:", error);
            const targetChannel = client.channels.cache.get(targetChannelId);
            targetChannel.send("An error occurred while setting up or stopping the reaction.");
        }
    }
};
